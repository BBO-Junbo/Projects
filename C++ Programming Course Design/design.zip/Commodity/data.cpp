#include "datatype.h"
CommodityInfo commodities[MAX_COMMODITY_NUM];
int commodityNum=0;
