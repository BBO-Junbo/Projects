#ifndef HEADER_H
#define HEADER_H
#include "datatype.h"
#include "function.h"
#include "help.h"
#include "data.h"

#endif // HEADER_H
