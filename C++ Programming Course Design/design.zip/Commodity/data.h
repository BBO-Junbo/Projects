#ifndef DATA_H
#define DATA_H
#include "datatype.h"
extern CommodityInfo commodities[MAX_COMMODITY_NUM];
extern int commodityNum;
#endif // DATA_H
