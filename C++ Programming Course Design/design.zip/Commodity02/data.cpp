#include "datatype.h"
int commodityNum=0;
int maxCommodityNum=1;
CommodityInfo *pCommodities;
