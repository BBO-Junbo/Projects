#ifndef DATA_H
#define DATA_H
#include "datatype.h"
extern int maxCommodityNum;
extern CommodityInfo *pCommodities;
extern int commodityNum;

#endif // DATA_H
