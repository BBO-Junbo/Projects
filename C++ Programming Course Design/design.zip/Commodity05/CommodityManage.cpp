#include "CommodityManage.h"
#include "Commodity.h"
#include "normalcommodity.h"
#include "overseacommodity.h"
#include <string>
#include <iostream>
#include <fstream>
#include<algorithm>
using namespace std;
CommodityManage::~CommodityManage(){
    for(auto e: pCommodities)
    delete e;

}

Commodity* CommodityManage::findCommodityById(int id){
    vector<Commodity*>::iterator it=find_if(pCommodities.begin(),
    pCommodities.end(), [=](Commodity* p){return p->getId()==id;});
    if(it!=pCommodities.end())
    return *it;
    return nullptr;

   }
const Commodity* CommodityManage::findCommodityById(int id)const{
    vector<Commodity*>::const_iterator it=find_if(pCommodities.begin(),
    pCommodities.end(), [=](const Commodity* p){return p->getId()==id;});
    if(it!=pCommodities.end())
    return *it;

    return nullptr;

}

void CommodityManage::addCommodity(Commodity* p){
    Commodity* pCommodity=findCommodityById(p->getId());
    if(pCommodity!=nullptr){
    cout<<"���Ϊ"<<p->getId()<<"����Ʒ�Ѿ�����!�ۼ�������\n";
    pCommodity->setNum(pCommodity->getNum()+p->getNum());
    return;
    }
    pCommodities.push_back(p);
    sortCommodities(); //������Ʒ����ݵ�ǰ������������


}


void CommodityManage::removeCommodity(int id){
    Commodity* pCommodity=findCommodityById(id);
    if(pCommodity==nullptr){
    cout<<"���Ϊ"<<id<<"����Ʒ������!\n";
    return;
    }
    delete pCommodity;
    pCommodities.erase(getIterator(pCommodity));

   }

void CommodityManage::viewCommodity(int id)const{
 const Commodity* pCommodity=findCommodityById(id);
 if(pCommodity==nullptr){
 cout<<"���Ϊ"<<id<<"����Ʒ������!\n";
 return;
 }
 pCommodity->output();
}
void CommodityManage::viewAllCommodities()const{
    cout<<"��Ʒ����:"<<pCommodities.size()<<endl;
    if(pCommodities.size()==0)
    return;
    cout<<"ָ������ʽ(0-��Ʒ id,1-��Ʒ����,2-��Ʒ����):";
    int type;
    cin>>type;
    const_cast<CommodityManage*>(this)->sortCommoditiesByType(type);
    for(auto e:pCommodities)
    e->output();
}


vector<Commodity*>::iterator CommodityManage::getIterator(Commodity* p){
 for(auto it=pCommodities.begin();it!=pCommodities.end();++it)
 if(*it==p)
 return it;
 return pCommodities.end();
}

void CommodityManage::saveData(string filename){
 ofstream out(filename);
 if(out){
 out<< pCommodities.size()<<endl;
 out<<Commodity::getNextId()<<endl;
 for(auto e : pCommodities){
 out<<e->getInfo();
 }
 }
}
void CommodityManage::readData(string filename){
 ifstream in(filename);
 if(in)
 {
 int fileSize;
 long nextId;
 in>>fileSize>>nextId;
 Commodity::setNextId(nextId);
 int type;
 long id;
 string name,buf;
 double price,discount;
 double tariff;
 int num;
 for(int i=0;i<fileSize;++i){
 in>>type;
 in>>id;
 getline(in,buf);
 getline(in,name);
 in>>price>>num;
 if(type==0){
 in>>discount;
 addCommodity(new
 NormalCommodity(id,name,price,num,discount));
 }
 else if(type==1){
 in>>discount>>tariff;
 addCommodity(new
 OverseaCommodity(id,name,price,num,discount,tariff));
 }
 }
in.close();
 }
 sortCommodities();

}


void CommodityManage::sortCommodities(){
 switch(sortType){
 case 0: //���� id ����
 sort(pCommodities.begin(),pCommodities.end(),
 [=](Commodity* p1,Commodity* p2){
 return p1->getId()<p2->getId();});
 break;
 case 1: //������������
 sort(pCommodities.begin(),pCommodities.end(),
 [=](Commodity* p1,Commodity* p2){
 return p1->getName()<p2->getName();});
 break;
 case 2: //���ݾ�������
 sort(pCommodities.begin(),pCommodities.end(),
 [=](Commodity* p1,Commodity* p2){
 return p1->getNetPrice()<p2->getNetPrice();});
 break;
 }
}
void CommodityManage::sortCommoditiesByType(int type){
 if(type==sortType) //�Ѿ���ָ����������ֱ�ӷ���
 return;
 sortType=type;
 sortCommodities();
}

