#ifndef SPECIALSCOMMODITY_H
#define SPECIALSCOMMODITY_H
#include <string>
#include "commodity.h"
#include "SpecialsCommodity.h"
class SpecialsCommodity : public Commodity{
public:
    virtual ~SpecialsCommodity(){}
    SpecialsCommodity(long id,std::string name,
    double p=0,int n=0,double d=0);
    SpecialsCommodity(std::string name,double p=0,int n=0,double d=0);
    void setDiscount(double specialprice){this->specialprice=specialprice;}
    double getSpecialprice()const{return specialprice;}
    virtual double getNetPrice()const;
    virtual void output()const;
    virtual int getType()const;
     virtual void change();
    virtual std::string getInfo()const;
private:
    double specialprice;
};

#endif // SPECIALSCOMMODITY_H
