#ifndef SECONDHANDCOMMODITY_H
#define SECONDHANDCOMMODITY_H
#include <string>
#include "commodity.h"
class SecondhandCommodity : public Commodity
{
public:
    virtual ~SecondhandCommodity(){}
    SecondhandCommodity(long id,std::string name,double p=0,int n=0,double dis=1.0,double de=1.0);
    SecondhandCommodity(std::string name,double p=0,int n=0,double dis=1.0,double de=1.0);
    void setDiscount(double discount){this->discount=discount;}
    void setDepreciation(double depreciation){this->depreciation=depreciation;}
    double getDiscount(){return discount;}
    double getdepreciation(){return depreciation;}
    virtual double getNetPrice()const;
    virtual void output()const;
    virtual int getType()const;
     virtual void change();
    virtual std::string getInfo()const;
private:
    double discount;
    double depreciation;
};

#endif // SECONDHANDCOMMODITY_H
