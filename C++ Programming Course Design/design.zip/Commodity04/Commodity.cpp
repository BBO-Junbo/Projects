#include <iostream>
#include "commodity.h"
#include <sstream>
using namespace std;
string Commodity::getInfo()const{
 ostringstream ostr;
 ostr<<getId()<<endl;
 ostr<<getName()<<endl;
 ostr<<price<<" "<<num<<" ";
 return ostr.str();
}

long Commodity::nextId=100;
Commodity::Commodity(string n,double p,int nu)
 :Commodity(autoNextId(),n,p,nu){}
Commodity::Commodity(long i,std::string n,double p,int nu)
 :id(i),name(n),price(p),num(nu){}
double Commodity::getNetPrice()const{
 return price*num;
}
void Commodity::output()const{
 cout<<" ��Ʒ���(id):"<<id<<endl;
 cout<<" ��Ʒ����:"<<name<<endl;
}
void Commodity::change()
{
    char choice;
    int num;
    double price;
    cout<<"0) ���޸ļ۸������\n";
    cout<<"1) �޸�����\n";
    cout<<"2) �޸ļ۸�\n";
    cin>>choice;
    switch(choice){
    case '0':
        break;
    case '1':
        cout<<"�������µ�������";
        cin>>num;
        this->num=num;
        cout<<"�޸ĳɹ�\n";
        break;
    case '2':
        cout<<"�������µļ۸�";
        cin>>price;
        this->price=price;
        cout<<"�޸ĳɹ�\n";
        break;
}
}

