#ifndef LEFTWIDGET_H
#define LEFTWIDGET_H
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QLine>
#include <QLCDNumber>
#include <QPushButton>
#include "paintlabel.h"
class MainWindow;

class LeftWidget : public QWidget
{
    Q_OBJECT
public:
    explicit LeftWidget(QWidget *parent = 0);

signals:

public slots:
    void addBall(); //添加小球
    void up();
    void addScore1();
    void addScore2();
    void addScore3();



private:
    QLabel *scoresLabel,
    *speedLabel,*angleLabel,*colorLabel;
    QLineEdit *speedEdit,*angleEdit;
    QLCDNumber *scoresout;
    PaintLabel *colorPreview;
    QPushButton *addButton;
    MainWindow *pmain; //指向主窗口的指针
    int scoreVal;
};

#endif // LEFTWIDGET_H
