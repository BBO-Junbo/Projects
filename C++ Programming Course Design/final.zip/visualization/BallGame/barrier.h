#ifndef BARRIER_H
#define BARRIER_H
#include <QColor>
#include <QRect>
#include <QPainter>
void drawbarrier (QPainter *p);
#endif // BARRIER_H
