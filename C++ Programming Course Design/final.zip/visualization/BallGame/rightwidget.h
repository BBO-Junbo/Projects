#ifndef RIGHTWIDGET_H
#define RIGHTWIDGET_H

#include "ball.h"
#include <QWidget>
#include <QList>
#include <QMouseEvent>
#include <QLabel>
#include "paintlabel.h"

class RightWidget : public QWidget
{
 Q_OBJECT
public:
    explicit RightWidget(QWidget *parent = 0);
    void paintEvent(QPaintEvent *);
    void updateBalls(); //移动小球的接口
    void addBall(const Ball& b); //添加小球的接口
protected:

private:
    QList<Ball> balls;


signals:
    void score1();
    void score2();
    void score3();
public slots:

private:
};


#endif // RIGHTWIDGET_H
