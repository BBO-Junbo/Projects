#include"barrier.h"
#include<QColor>
void drawbarrier (QPainter *p)
{
    QPen pen(Qt::black,3,Qt::SolidLine);
    QBrush brush1(Qt::green);
    QBrush brush2(Qt::yellow);
    QBrush brush3(Qt::red);
    QBrush brush4(Qt::black);
    p->setPen(pen);

    p->setBrush(brush1);
    QRect r1(1580,0,20,300);
    p->drawRect(r1);

    p->setBrush(brush2);
    QRect r2(1580,300,20,125);
    p->drawRect(r2);

    p->setBrush(brush3);
    QRect r3(1580,425,20,50);
    p->drawRect(r3);

    p->setBrush(brush2);
    QRect r4(1580,475,20,125);
    p->drawRect(r4);

    p->setBrush(brush1);
    QRect r5(1580,600,20,300);
    p->drawRect(r5);

    p->setBrush(brush4);
    QRect r6(1400,0,200,20);
    p->drawRect(r6);

    p->setBrush(brush4);
    QRect r7(1400,880,200,20);
    p->drawRect(r7 );
}


