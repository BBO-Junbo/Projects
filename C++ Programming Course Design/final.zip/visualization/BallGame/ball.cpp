#include <cmath>
#include <QPen>
#include <QBrush>
#include "ball.h"
Ball::Ball():Ball(40,100,10,10,45,Qt::red)
{ //通过委托构造实现缺省构造函数
}
Ball::Ball(double xpos,double ypos,double r,double s,double a,QColor c)
 :x(xpos),y(ypos),radius(r),speed(s),angle(a),color(c){
    double PI=3.14159;
    vx=speed*std::sin(angle*PI/180);
    vy=speed*std::cos(angle*PI/180);
    isCount = false;
}
void Ball::draw(QPainter *p)
{
    QPen pen(color,1,Qt::SolidLine);
    QBrush brush(color);
    p->setPen(pen);
    p->setBrush(brush);
    QRect r(x-radius,y-radius,radius*2,radius*2);
    p->drawEllipse(r);
}
void Ball::move(){
    double dx,dy;
    dx=vx;
    dy=vy;
    x+=dx;
    y+=dy;
    checkBoundary();
    Damping(0,speed);
}
bool Ball::checkBoundary(){
    if(y+radius>rect.height()){


        if(x>=1400&&x<=1600)
        {
          return false;
        }
        y=rect.height()-radius;
        vy*=-1;
        return false;
    }
    if(y-radius<0){

        if(x>=1400&&x<=1600)
        {
          return false;
        }
        y=radius;
        vy*=-1;
        return false;
    }
    if(x+radius>rect.width()){


        return true;


    }
    if(x-radius<0){


        x=radius;
        vx*=-1;
        return false;
    }
}
void Ball::checkCollision(Ball &b){



    //计算的是下一刻的位置，以免发生粘连
    float disX = (x+vx)-(b.x+b.vx);
    float disY = (y+vy)-(b.y+b.vy);
    float dis = sqrt(disX*disX+disY*disY);
    //判断下一刻是否 发生碰撞

    if(dis<radius+b.radius){

        double v1x=vx,v1y=vy,v2x=b.vx,v2y=b.vy;
        double x1=x,y1=y,x2=b.x,y2=b.y;

        vx=(v1x*pow((y2-y1),2)+v2x*pow((x2-x1),2)+(v2y-v1y)*(x2-x1)*(y2-y1))/(pow((x2-x1),2)+pow((y2-y1),2));
        vy=(v1y*pow((x2-x1),2)+v2y*pow((y2-y1),2)+(v2x-v1x)*(x2-x1)*(y2-y1))/(pow((x2-x1),2)+pow((y2-y1),2));
        b.vx=(v1x*pow((x2-x1),2)+v2x*pow((y2-y1),2)-(v2y-v1y)*(x2-x1)*(y2-y1))/(pow((x2-x1),2)+pow((y2-y1),2));
        b.vy=(v1y*pow((y2-y1),2)+v2y*pow((x2-x1),2)-(v2x-v1x)*(x2-x1)*(y2-y1))/(pow((x2-x1),2)+pow((y2-y1),2));
        double temp=angle;
        angle=b.angle;
        b.angle=temp;
        Damping(1,speed);
        Damping(1,b.speed);
        x+=1;
        y+=1;
        b.x-=1;
        b.y-=1;

    }
}
void Ball::Damping(int type,double Speed)
{
    switch(type)
    {
        case 0:
            this->speed=Speed*0.99;
            break;
        case 1:
            this->speed=Speed*0.95;
            break;
    }
    if(this->speed<0.1)
        this->speed=0;
}
