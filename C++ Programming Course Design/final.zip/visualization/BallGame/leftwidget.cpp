#include "leftwidget.h"
#include <QGridLayout>
#include <QPalette>
#include <QEvent>
#include <QPainter>
#include <QString>
#include <qDebug>
#include "mainwindow.h"
#include "rightwidget.h"
LeftWidget::LeftWidget(QWidget *parent) :
    QWidget(parent)
{

    scoreVal = 0;
    pmain=(MainWindow *)parent;

    scoresLabel=new QLabel(this);
    scoresLabel->setText(tr("得分:"));

    QString s=QString::number(0,10);
    scoresout=new QLCDNumber();
    scoresout->display(s);


    speedLabel=new QLabel(this);
    speedLabel->setText(tr("速度:"));
    angleLabel=new QLabel(this);
    angleLabel->setText(tr("角度:"));
    colorLabel=new QLabel(this);
    colorLabel->setText(tr("颜色:"));


    speedEdit=new QLineEdit("50",this);

    colorPreview=new PaintLabel(this);
    colorPreview->setText(tr(" ")); //初始字符串确定控件大小

    angleEdit=new QLineEdit("80",this);

    addButton=new QPushButton(tr("发射"),this);

    QGridLayout *mainLayout=new QGridLayout(this);

    mainLayout->addWidget(scoresLabel,0,0);
    mainLayout->addWidget(scoresout,0,1);
    mainLayout->addWidget(speedLabel,1,0);
    mainLayout->addWidget(speedEdit,1,1);
    mainLayout->addWidget(angleLabel,2,0);
    mainLayout->addWidget(angleEdit,2,1);
    mainLayout->addWidget(colorLabel,3,0);
    mainLayout->addWidget(colorPreview,3,1);
    mainLayout->addWidget(addButton,4,0.5);
    setLayout(mainLayout);
    connect(addButton,SIGNAL(clicked()),this,SLOT(addBall()));

}
void LeftWidget::addBall(){
    RightWidget *right=pmain->getRightWidget();
    //pmain 时指向主窗口的指针，通过其接口 getRightWidget 获得
    //右侧窗口指针，再调用 right 的 addBall 接口添加小球

    double angle,speed;
    QColor fillColor;
    bool ok;
    speed=speedEdit->text().toDouble(&ok);
    angle=angleEdit->text().toDouble(&ok);
    fillColor=colorPreview->getFillColor();
    right->addBall(Ball(0,450,20 ,speed,angle,fillColor));//坐标 半径 速度
}

void LeftWidget::up()
{
    update();
}
void LeftWidget::addScore1()
{
    scoreVal += 1;
    qDebug()<<scoreVal;
    scoresout->display(QString::number(scoreVal,10));
}
void LeftWidget::addScore2()
{
    scoreVal += 2;
    qDebug()<<scoreVal;
    scoresout->display(QString::number(scoreVal,10));
}
void LeftWidget::addScore3()
{
    scoreVal += 3;
    qDebug()<<scoreVal;
    scoresout->display(QString::number(scoreVal,10));
}
