#include "rightwidget.h"
#include "barrier.h"
#include <QPainter>



RightWidget::RightWidget(QWidget *parent) :
 QWidget(parent)
{

    setMinimumSize(1600,900);
    balls.clear(); //清空后手工添加 3 个小球，用于测试

    addBall(Ball(300,600,50,30,0,Qt::black));
    addBall(Ball(400,600,20,80,180,Qt::black));
    addBall(Ball(500,700,10,100,0,Qt::black));
    addBall(Ball(600,900,20,40,180,Qt::black));
    addBall(Ball(700,1000,10,50,0,Qt::black));

}
void RightWidget::addBall(const Ball &b){

    balls.append(b);
}

void RightWidget::paintEvent(QPaintEvent *)
{


    QPainter p(this);
    drawbarrier(&p);
    for(auto& b:balls)
    {
        b.draw(&p);
        if(b.checkBoundary()&&(b.getX()>1580))
        {
            if(b.isCount == false)
            {
                if(b.getY()<301||b.getY()>600)
                {
                 //绿色
                 emit score1();
                }
                else if((b.getY()<426&&b.getY()>300)||(b.getY()<601&&b.getY()>475))
                {
                     //黄色
                    emit score2();
                }
                else
                {
                     //红色
                    emit score3();
                }
                b.isCount = true;
            }

        }


    }


}
void RightWidget::updateBalls() //封装的控制小球移动的接口
{
    for(auto &b:balls){

        b.setRectangle(this->geometry());
        b.move();
    }
    int i,j;
    //判断是否发生碰撞
    for(i=0;i<balls.size()-1;++i)
    {
        for(j=i+1;j<balls.size();++j)
        {

            balls[i].checkCollision(balls[j]);
        }
    }


    update(); //更新窗口显示，重绘小球
}

