#ifndef STUDENTMANGE_H
#define STUDENTMANGE_H
#include <string>
#include <vector>
#include "Student.h"
class StudentManage
{
public:
    StudentManage()=default;
    ~StudentManage();
    StudentManage(const StudentManage& c)=delete;
    StudentManage& operator=(const StudentManage& c)=delete;
    void addStudent(Student* p);
    void removeStudent(long sid);
    void viewStudent(long sid)const;
    void viewAllStudents()const;
    void changeInf(int sid);
    void readData(std::string filename);
    void saveData(std::string filename);


private:
    std::vector<Student*> pStudents;
    Student* findStudentBySId(long sid);
    const Student* findStudentBySId(long sid)const;
    std::vector<Student*>::iterator getIterator(Student* p);
    int sortType=0; //��¼��ǰ��������
    void sortStudents();
    void sortStudentByType(int type);
};

#endif // STUDENTMANGE_H
