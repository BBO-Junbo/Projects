#ifndef INTERNATIONALSTUDENT_H
#define INTERNATIONALSTUDENT_H
using namespace std;
#include "Student.h"
class InternationalStudent : public Student
{
public:
    virtual ~InternationalStudent(){}
    InternationalStudent(long si,std::string n,std::string gdr,
                  int a,int gra,std::string sch,
                  std::string ma,double gp,double sco,string na);
    void setNationality(double n){this->nationality=n;}
    std::string getNationality()const{return nationality;}
    virtual void output()const;
    virtual int getType()const;
    virtual std::string getInfo()const;
    virtual void change();
private:
    std::string nationality;

};
#endif // INTERNATIONALSTUDENT_H
