#ifndef NORMALSTUDENT_H
#define NORMALSTUDENT_H
#include <iostream>
#include "Student.h"
class NormalStudent:public Student
{
public:
    virtual ~NormalStudent(){}
    NormalStudent(long si,std::string n,std::string gdr,
                  int a,int gra,std::string sch,
                  std::string ma,double gp,double sco,std::string ho);
    void sethometown(double h){this->hometown=h;}
    std::string getHometown()const{return hometown;}
    virtual void output()const;
    virtual int getType()const;
    virtual std::string getInfo()const;
    void change();

private:
 std::string hometown;
};
#endif // NORMALSTUDENT_H
