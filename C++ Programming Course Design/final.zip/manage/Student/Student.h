#ifndef STUDENT_H
#define STUDENT_H
#include <string>
class Student
{
public:
    virtual ~Student(){}
    Student()=default;
    Student(long i,long si,std::string n,std::string gdr,
            int a,int gra,std::string sch,
            std::string ma,double gp,double sco);
    Student(long si,std::string n,std::string gdr,
            int a,int gra,std::string sch,
            std::string ma,double gp,double sco);

    virtual void output()const;
    virtual int getType()const=0; //���麯��
    virtual std::string getInfo()const;
    virtual void change();

/*******************������Ϣ***************************/
    void setStudentId(long sid){this->studentId=sid;}
    void setName(std::string n){this->name=n;}
    void setGender(std::string g){this->gender=g;}
    void setAge(int a){this->age=a;}//
    void setGrade(int g){this->grade=g;}
    void setSchool(std::string s){this->school=s;}
    void setMajor(std::string m){this->major=m;}
    void setGpa(double g){this->gpa=g;}//
    void setScores(double s){this->scores=s;}
/****************************************************/

/*******************��ȡ��Ϣ*****************************/
    long getId()const{return id;}
    long getStudentId()const{return studentId;}
    std::string getName()const{return name;}
    std::string getGender()const{return gender;}
    int getAge()const{return age;}
    int getGrade()const{return grade;}
    std::string getSchool()const{return school;}
    std::string getMajor()const{return major;}
    double getGpa()const{return gpa;}
    double getScores()const{return scores;}
    static void setNextId(long id){nextId=id;}
    static long getNextId(){return nextId;}
/******************************************************/
private:
    long id;             //�洢���
    long studentId;      //ѧ��
    std::string name;    //����
    std::string gender;  //�Ա�
    int age;             //����
    int grade;           //�꼶
    std::string school;  //ѧԺ
    std::string major;   //רҵ
    double gpa;          //ѧ�ּ���
    double scores;       //��Ȩƽ����
    static long nextId;
    long autoNextId(){return nextId++;}


};

#endif // STUDENT_H
