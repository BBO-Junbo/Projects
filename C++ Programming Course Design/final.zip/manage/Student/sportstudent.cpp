#include<iostream>
#include"sportstudent.h"
#include "Student.h"
#include <sstream>
using namespace std;
int SportStudent::getType()const
{
    return 2; //1 ��ʾ������
}

SportStudent::SportStudent(long si,std::string n,std::string gdr,
                             int a,int gra,std::string sch,
                             std::string ma,double gp,double sco,string pr)
                :Student(si,n,gdr,a,gra,sch,ma,gp,sco),project(pr){}

void SportStudent::output()const
{
    Student::output();
    cout<<"������Ŀ:"<<getProject()<<endl;
    cout<<"###########################################"<<endl<<endl;
}

string SportStudent::getInfo()const
{
    ostringstream ostr;
    ostr<<getType()<<endl;
    ostr<<getStudentId()<<endl;
    ostr<<getName()<<endl;
    ostr<<getGender()<<endl;
    ostr<<getAge()<<endl;
    ostr<<getGrade()<<endl;
    ostr<<getSchool()<<endl;
    ostr<<getMajor()<<endl;
    ostr<<getGpa()<<endl;
    ostr<<getScores()<<endl;
    ostr<<getProject()<<endl;
    return ostr.str();
}
void SportStudent::change()
{
    Student::change();
    string pro;
    cout<<" ������Ŀ-9"<<endl;
    cout<<" �Ƿ��޸�������Ŀ(9-�ǣ���������-��)";
    char choice1;
    cin>>choice1;
    switch(choice1)
    {
    case '9':
        cout<<"�������µ�������Ŀ��";
        cin>>pro;
        this->project=pro;
        cout<<"�޸ĳɹ�\n";
        break;
    default:
        break;
    }
    cout<<"###########################################"<<endl<<endl;
}
