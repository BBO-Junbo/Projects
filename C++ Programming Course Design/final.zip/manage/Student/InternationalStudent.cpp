#include<iostream>
#include"InternationalStudent.h"
#include "Student.h"
#include <sstream>
using namespace std;
int InternationalStudent::getType()const
{
    return 1; //1 ��ʾ����ѧ��
}

InternationalStudent::InternationalStudent(long si,std::string n,std::string gdr,
                             int a,int gra,std::string sch,
                             std::string ma,double gp,double sco,string na)
                :Student(si,n,gdr,a,gra,sch,ma,gp,sco),nationality(na){}

void InternationalStudent::output()const
{
    Student::output();
    cout<<"����:"<<getNationality()<<endl;
    cout<<"###########################################"<<endl<<endl;
}

string InternationalStudent::getInfo()const
{
    ostringstream ostr;
    ostr<<getType()<<endl;
    ostr<<getStudentId()<<endl;
    ostr<<getName()<<endl;
    ostr<<getGender()<<endl;
    ostr<<getAge()<<endl;
    ostr<<getGrade()<<endl;
    ostr<<getSchool()<<endl;
    ostr<<getMajor()<<endl;
    ostr<<getGpa()<<endl;
    ostr<<getScores()<<endl;
    ostr<<getNationality()<<endl;
    return ostr.str();
}
void InternationalStudent::change()
{
    Student::change();
    string na;
    cout<<" ����-9"<<endl;
    cout<<" �Ƿ��޸Ĺ���(9-�ǣ���������-��)";
    char choice1;
    cin>>choice1;
    switch(choice1)
    {
    case '9':
        cout<<"�������µĹ�����";
        cin>>na;
        this->nationality=na;
        cout<<"�޸ĳɹ�\n";
        break;
    default:
        break;
    }
    cout<<"###########################################"<<endl<<endl;
}
