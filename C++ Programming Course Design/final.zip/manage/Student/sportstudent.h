#ifndef PE_H
#define PE_H
#include <iostream>
#include "Student.h"
class SportStudent:public Student
{
public:
    virtual ~SportStudent(){}
    SportStudent(long si,std::string n,std::string gdr,
                  int a,int gra,std::string sch,
                  std::string ma,double gp,double sco,std::string pr);
    void setproject(double pr){this->project=pr;}
    std::string getProject()const{return project;}
    virtual void output()const;
    virtual int getType()const;
    virtual std::string getInfo()const;
    void change();

private:
    std::string project;
};
#endif // PE_H
