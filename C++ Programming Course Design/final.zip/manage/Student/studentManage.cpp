#include "Student.h"
#include "studentManage.h"
#include "InternationalStudent.h"
#include "NormalStudent.h"
#include "sportstudent.h"
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
StudentManage::~StudentManage()
{
    for(auto e: pStudents)
    delete e;
}
Student* StudentManage::findStudentBySId(long sid)
{
    vector<Student*>::iterator it=find_if(pStudents.begin(),
    pStudents.end(), [=](Student* p){return p->getStudentId()==sid;});
    if(it!=pStudents.end())
        return *it;
    return nullptr;

}
const Student* StudentManage::findStudentBySId(long sid)const{
    vector<Student*>::const_iterator it=find_if(pStudents.begin(),
    pStudents.end(), [=](const Student* p){return p->getStudentId()==sid;});
    if(it!=pStudents.end())
        return *it;
    return nullptr;

}

void StudentManage::addStudent(Student* p){
    Student* pStudent=findStudentBySId(p->getStudentId());
    if(pStudent!=nullptr)
    {
        cout<<"ѧ��Ϊ"<<p->getStudentId()<<"��ѧ���Ѿ�����!";
        return;
    }
    pStudents.push_back(p);
    sortStudents(); //����ѧ������ݵ�ǰ������������


}


void StudentManage::removeStudent(long sid){
    Student* pStudent=findStudentBySId(sid);
    if(pStudent==nullptr)
    {
        cout<<"ѧ��Ϊ"<<sid<<"��ѧ��������!\n";
        return;
    }
        delete pStudent;
    pStudents.erase(getIterator(pStudent));

   }

void StudentManage::viewStudent(long sid)const{
 const Student* pStudent=findStudentBySId(sid);
 if(pStudent==nullptr)
 {
    cout<<"ѧ��Ϊ"<<sid<<"��ѧ��������!\n";
    return;
 }
    pStudent->output();
}
void StudentManage::viewAllStudents()const{
    cout<<"ѧ������:"<<pStudents.size()<<endl;
    if(pStudents.size()==0)
        return;
    cout<<"ָ������ʽ(0-ѧ�� id,1-����,2-ѧ�ּ���):";
    int type;
    cin>>type;
    const_cast<StudentManage*>(this)->sortStudentByType(type);
    for(auto e:pStudents)
    e->output();
}
void StudentManage::changeInf(int sid)
{
    Student* pStudent=findStudentBySId(sid);
    if(pStudent==nullptr){
    cout<<"ѧ��Ϊ"<<sid<<"��ѧ��������!\n";
    return;
    }
    pStudent->change();
}

vector<Student*>::iterator StudentManage::getIterator(Student* p){
    for(auto it=pStudents.begin();it!=pStudents.end();++it)
        if(*it==p)
    return it;
    return pStudents.end();
}

void StudentManage::sortStudents(){
    switch(sortType){
        case 0: //����ѧ������
            sort(pStudents.begin(),pStudents.end(),[=](Student* p1,Student* p2){
            return p1->getStudentId()<p2->getStudentId();});
            break;
        case 1: //������������
            sort(pStudents.begin(),pStudents.end(),[=](Student* p1,Student* p2){
            return p1->getName()<p2->getName();});
            break;
        case 2: //����ѧ�ּ�������
            sort(pStudents.begin(),pStudents.end(),[=](Student* p1,Student* p2){
            return p1->getGpa()<p2->getGpa();});
        break;
   }
}
void StudentManage::sortStudentByType(int type){
 if(type==sortType) //�Ѿ���ָ����������ֱ�ӷ���
 return;
 sortType=type;
 sortStudents();
}
void StudentManage::saveData(string filename)
{
    ofstream out(filename);
    if(out){
        out<< pStudents.size()<<endl;
        for(auto e : pStudents){
        out<<e->getInfo();
 }
 }
}
void StudentManage::readData(string filename){
    ifstream in(filename);
    if(in)
    {
        int fileSize;
        in>>fileSize;
        int type;
        long studentId;      //ѧ��
        string name;         //����
        string gender;       //�Ա�
        int age;             //����
        int grade;           //�꼶
        string school;       //ѧԺ
        string major;        //רҵ
        double gpa;          //ѧ�ּ���
        double scores;       //��Ȩƽ����
        string hometown;     //��Դ��
        string nationality;  //����
        string project;      //������Ŀ
        for(int i=0;i<fileSize;++i){
            in>>type;
            in>>studentId;
            in>>name;
            in>>gender;
            in>>age;
            in>>grade;
            in>>school;
            in>>major;
            in>>gpa;
            in>>scores;
            if(type==0){

                in>>hometown;
                addStudent(new
                NormalStudent(studentId,name,gender,age,grade,school,major,gpa,scores,hometown));
            }
            else if(type==1){

                in>>nationality;
                addStudent(new
                InternationalStudent(studentId,name,gender,age,grade,school,major,gpa,scores,nationality));
            }
            else if(type==2){

                in>>project;
                addStudent(new
                SportStudent(studentId,name,gender,age,grade,school,major,gpa,scores,project));
            }
       }
    in.close();
    }
    sortStudentByType(0);
}

