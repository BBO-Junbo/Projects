#include <iostream>
#include"studentManage.h"
#include"function.h"
using namespace std;

using namespace std;
int main()
{
    cout<<"��ӭʹ��ѧ������ϵͳ!\n";
    char choice;
    StudentManage sm;
    sm.readData("d:\\student.text");
    while(true){
        choice=menu();
    if(choice=='0')
        break;
    switch(choice){
        case '1':
            doAddStudent(sm);
            break;
        case '2':
            doRemoveStudent(sm);
            break;
        case '3':
            doViewStudent(sm);
            break;
        case '4':
            doViewAllStudent(sm);
            break;
        case '5':
            doChangeInf(sm);
            break;
        default:
            cout<<"��Ч����! ������!\n";
    }
   }
    cout<<"�ټ�!\n";
    sm.saveData("d:\\student.text");
    return 0;
}
