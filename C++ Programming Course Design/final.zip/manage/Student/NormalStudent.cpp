#include<iostream>
#include"NormalStudent.h"
#include "Student.h"
#include <sstream>
using namespace std;
int NormalStudent::getType()const
{
    return 0; //0 ��ʾ��ͨѧ��
}

NormalStudent::NormalStudent(long si,std::string n,std::string gdr,
                             int a,int gra,std::string sch,
                             std::string ma,double gp,double sco,string ho)
                :Student(si,n,gdr,a,gra,sch,ma,gp,sco),hometown(ho){}

void NormalStudent::output()const
{
    Student::output();
    cout<<" ��Դ��:"<<getHometown()<<endl;
    cout<<"###########################################"<<endl<<endl;
}
string NormalStudent::getInfo()const
{
    ostringstream ostr;
    ostr<<getType()<<endl;
    ostr<<getStudentId()<<endl;
    ostr<<getName()<<endl;
    ostr<<getGender()<<endl;
    ostr<<getAge()<<endl;
    ostr<<getGrade()<<endl;
    ostr<<getSchool()<<endl;
    ostr<<getMajor()<<endl;
    ostr<<getGpa()<<endl;
    ostr<<getScores()<<endl;
    ostr<<getHometown()<<endl;
    return ostr.str();
}
void NormalStudent::change()
{
    Student::change();
    string home;
    char choice1;
    cout<<" ��Դ��-9"<<endl;
    cout<<" �Ƿ��޸���Դ��(9-�ǣ���������-��)";
    cin>>choice1;
    switch(choice1)
    {
    case '9':
        cout<<"�������µ���Դ�أ�";
        cin>>home;
        this->hometown=home;
        cout<<"�޸ĳɹ�\n";
        break;
    default:
        break;
   }
    cout<<"###########################################"<<endl<<endl;
}
