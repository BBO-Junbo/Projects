#ifndef FUNCTION_H
#define FUNCTION_H
#include "studentManage.h"
char menu();
void doAddStudent(StudentManage& sm);
void doRemoveStudent(StudentManage& sm);
void doViewStudent(const StudentManage& sm);
void doViewAllStudent(const StudentManage& sm);
void doChangeInf(StudentManage &sm);

#endif // FUNCTION_H
