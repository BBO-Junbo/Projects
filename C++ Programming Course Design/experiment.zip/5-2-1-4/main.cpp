#include <iostream>
#include<cmath>
using namespace std;

class Point
{
public:
    Point(double newX=0,double newY=0);
    Point(const Point& p);
    void setValue(double newX, double newY);
    double getX( ) const;
    double getY() const;
    double getDistance(const Point& p2) const;
private:
    double x, y;
};
Point::Point(double newX,double newY):x(newX),y(newY){}
Point::Point(const Point &p)
{
    this->x=p.getX();
    this->y=p.getY();
}

void Point::setValue(double newX,double newY)
{
    x=newX;
    y=newY;
}

double Point::getX()const
{
    return x;
}
double Point::getY()const
{
    return y;
}
double Point::getDistance(const Point&p2)const//2）中的内容
{
    return sqrt(pow(this->x-p2.x,2)+pow(this->y-p2.y,2));
}

class Point3D : public Point
{
public:
    Point3D(double newX=0, double newY=0, double newZ=0);
    Point3D(const Point& p);
    double getZ() const;
    double getDistance( const Point3D& p)const;
private:
    double z;
};

Point3D::Point3D(double newX, double newY, double newZ)
{
    setValue(newX,newY);
    z=newZ;
}
Point3D::Point3D(const Point& p): Point(p), z(0) {}
double Point3D::getZ()const
{
    return z;
}
double Point3D::getDistance(const Point3D&p2)const
{
    return sqrt(pow(this->getX()-p2.getX(),2)+pow(this->getY()-p2.getY(),2)+pow(this->getZ()-p2.getZ(),2));
}
int main(){
Point p1(3, 4), p2(5,3);
Point3D p1_3D(3,4,6);
Point3D p2_3D(2,6,9);
double dis=p1.getDistance(p2); //计算二维点 p1 和 p2 的距离
cout<<"Distance between p1 and p2: "<<dis<<endl;
dis=p1.getDistance(p2_3D); //计算 p1 和 p2_3D 的距离
cout<<"Distance between p1 and p2_3D: "<<dis<<endl;
dis=p1_3D.getDistance(p2); //计算点 p1_3D 和 p2 的距离
cout<<"Distance between p1_3D and p2: "<<dis<<endl;
return 0;
}
