#include <iostream>
#include"Array1D.h"
using namespace std;

int main(){
Array1D <int> array(5);
for(int i=0;i<array.getSize();++i)
array [i]=i+1;
cout<<"Max: "<< array.max()<<endl;
for(int i=0;i<array.getSize();++i)
cout<<array[i]<< " ";
cout<<endl;
cout<<array;
return 0;

}
