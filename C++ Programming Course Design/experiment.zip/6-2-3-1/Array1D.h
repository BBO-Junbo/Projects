#include<iostream>
using namespace std;
template <typename T>
class Array1D
{
public:
    Array1D (int newSize); //指定数组大小
    Array1D (T *p, int newSize); //指定数组大小并传递初始值
    Array1D ( const Array1D <T>& a); //拷贝构造函数
    ~Array1D ();
    int getSize()const; //获取数组的大小
    T max()const; //获取数组的最大值
    void reverse(); //逆转数组元素
    const T& operator[](int index)const;
    T& operator[](int index);
    Array1D& operator=(const Array1D<T>& a); //赋值运算符

    template <typename X>
    friend ostream& operator<<( ostream& out, const Array1D <X>& t);
private:
    T *pData; //指向堆中数组的指针
    int size; //数组元素个数
};

template <typename T>
Array1D<T>::Array1D (int newSize) //指定数组大小
{
    this->size=newSize;
    pData=new T[size];
}

template <typename T>
Array1D<T>::Array1D (T *p, int newSize) //指定数组大小并传递初始值
{
    this->size=newSize;
    pData=new T[size];
    for(int i=0;i<size;++i)
    {
        *pData=*p;
        pData++;
        p++;
    }
}

template <typename T>
Array1D<T>::Array1D ( const Array1D <T>& a) //拷贝构造函数
{
    this->size=a.getSize();
    this->pData=new T[size];
    for(int i=0;i<size;++i)
    {
        *pData=a.pData;
        this->pData++;
        a.pData++;
    }
}

template <typename T>
Array1D<T>::~Array1D ()
{
    delete []pData;
}

template <typename T>
int Array1D<T>::getSize()const //获取数组的大小
{
    return size;
}

template <typename T>
T Array1D<T>::max()const //获取数组的最大值
{
    T max=*pData;
    for(int i=1;i<size;i++)
    {
        if(*(pData+i)>max)
            max=*(pData+i);
    }
    return max;
}

template <typename T>
void Array1D<T>::reverse()//逆转数组元素
{
    for(int i=0;i<size/2;++i)
    {
        T temp=*(pData+size-1-i);
        *(pData+size-1-i)=*(pData+i);
        *(pData+i)=temp;
    }
}

template <typename T>
const T& Array1D<T>:: operator[](int index)const
{
    return *(pData+index);
}

template <typename T>
T& Array1D<T>::operator[](int index)
{
    return *(pData+index);
}

template <typename T>
Array1D<T>& Array1D<T>::operator=(const Array1D<T>& a)//赋值运算符
{
    for(int i=0;i<size;++i)
    {
        this->*(pData+i)=a.*(pData+i);
    }
    return *this;
}

template <typename X>
ostream& operator<<( ostream& out, const Array1D <X>& t)
{
    for(int i=0;i<t.getSize();++i)
    {
        out<<*(t.pData+i)<<' ';
    }
}

