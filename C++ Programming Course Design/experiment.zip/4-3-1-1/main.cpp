#include <iostream>
#include <math.h>
using namespace std;

class Complex
{
public:
    Complex():real(0),image(0){}
    Complex(double r):real(r),image(0){};
    Complex(double r,double i):real(r),image(i){};
    void setValue(double r,double i)
        {
            this->real=r;
            this->image=i;
        }
    double getReal()const
    {
        return real;
    }
    double getImage()const
    {
        return image;
    }
    double getDistance()const
    {
        return sqrt(abs(real*real)+abs(image*image));
    }
    void output()const
    {
        if(real!=0)
        {
            if(image==0)
                cout<<real<<endl;
            else if(image>0)
                cout<<real<<"+"<<image<<"i"<<endl;
            else if(image<0)
                cout<<real<<image<<"i"<<endl;
        }
        else
        {
            if(image==0)
                cout<<"0"<<endl;
            else
                cout<<image<<"i"<<endl;
        }

    }
    Complex operator+(const Complex& f)const
    {
        return Complex(this->real+f.real,this->image+f.image);
    }
    Complex operator*(const Complex& f)const
    {
        return Complex(this->real*f.real-this->image*f.image,this->real*f.image+this->image*f.real);
    }
    Complex & operator+=(const Complex & f)
    {
        this->real=this->real+f.real;
        this->image=this->image+f.image;
        return *this;
    }
    Complex & operator*=(const Complex & f)
    {
        this->real=this->real*f.real-this->image*f.image;
        this->image=this->real*f.image+this->image*f.real;
        return *this;
    }

    Complex & operator ++() //前置++，实部加 1
    {
        this->real++;
        return *this;
    }

    Complex operator++(int) //后置++，实部加 1
    {
        Complex temp=*this;
        this->real++;
        return temp;
    }

private:
    double real;
    double image;
};

int main()
{
    Complex c1,c2(2),c3(3,4),c4;
    c1.output();
    c2.output();
    c3.output();
    c1.setValue(6,4);
    c1.output();
    c4=c1+c3;
    cout<<c1.getDistance()<<endl;
    c4.output();
    c4=c1*c3;
    c4.output();
    c3++;
    c3.output();
    return 0;
}

