#include <iostream>
#include <math.h>
using namespace std;

class Complex
{
public:
    Complex():real(0),image(0){}
    Complex(double r):real(r),image(0){};
    Complex(double r,double i):real(r),image(i){};
    void setValue(double r,double i)
        {
            this->real=r;
            this->image=i;
        }
    double getReal()const
    {
        return real;
    }
    double getImage()const
    {
        return image;
    }
    double getDistance()const
    {
        return sqrt(abs(real*real)+abs(image*image));
    }
//    void output()const
//    {
//        if(real!=0)
//        {
//            if(image==0)
//                cout<<real<<endl;
//            else if(image>0)
//                cout<<real<<"+"<<image<<"i"<<endl;
//            else if(image<0)
//                cout<<real<<image<<"i"<<endl;
//        }
//        else
//        {
//            if(image==0)
//                cout<<"0"<<endl;
//            else
//                cout<<image<<"i"<<endl;
//        }

//    }

    friend std::ostream& operator<<( std::ostream& out, const Complex& f);
    Complex operator+(const Complex& f)const
    {
        return Complex(this->real+f.real,this->image+f.image);
    }
    Complex operator*(const Complex& f)const
    {
        return Complex(this->real*f.real-this->image*f.image,this->real*f.image+this->image*f.real);
    }
    Complex & operator+=(const Complex & f)
    {
        this->real=this->real+f.real;
        this->image=this->image+f.image;
        return *this;
    }
    Complex & operator*=(const Complex & f)
    {
        this->real=this->real*f.real-this->image*f.image;
        this->image=this->real*f.image+this->image*f.real;
        return *this;
    }

    Complex & operator ++() //前置++，实部加 1
    {
        this->real++;
        return *this;
    }

    Complex operator++(int) //后置++，实部加 1
    {
        Complex temp=*this;
        this->real++;
        return temp;
    }
    Complex& operator-=(const Complex & f)
    {
        this->real=this->real-f.real;
        this->image=this->image-f.image;
        return *this;
    }

    friend Complex operator-(const Complex & f1, const Complex & f2);
private:
    double real;
    double image;
};
std::ostream& operator<<( std::ostream& out, const Complex& f)
{

    if(f.real!=0)
    {
        if(f.image==0)
            out<<f.real<<endl;
        else if(f.image>0)
            out<<f.real<<"+"<<f.image<<"i"<<endl;
        else if(f.image<0)
            out<<f.real<<f.image<<"i"<<endl;
    }
    else
    {
        if(f.image==0)
            out<<"0"<<endl;
        else
            out<<f.image<<"i"<<endl;
    }
    return out;
}

Complex operator-(const Complex & f1, const Complex & f2)
{
    return Complex(f1.real-f2.real,f1.image-f2.image);
}

int main()
{
    Complex c1,c2(2),c3(3,4),c4;
    cout<<c2;
    cout<<c3;
    c1.setValue(6,4);
    c4=c1-c3;
    cout<<c4;
    return 0;
}
