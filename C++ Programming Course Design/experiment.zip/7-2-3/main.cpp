#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
class Student
{
private:
    string name;
    string specialty;//专业
    long id;// 学号
    double creditPoint; //学分积点
public:
    Student(string n,string s,long i,double c):name(n),specialty(s),id(i),creditPoint(c){}
    void setCreditPoint(double c)
    {
        creditPoint=c;
    }

    double getCreditPoint()const
    {
        return creditPoint;
    }
    string getName()const
    {
        return name;
    }
    long getId()const
    {
        return id;
    }
    string getSpecialty()const
    {
        return specialty;
    }
    friend std::ostream& operator<<(std::ostream& out,const Student& s);
};
ostream& operator<<(ostream& out,const Student& s)
{
    out<<"Name:"<<s.name<<endl;
    out<<" Id:"<<s.id<<endl;
    out<<" Specialty:"<<s.specialty<<endl;
    out<<" CreditPoint:"<<s.creditPoint<<endl;
    return out;
}


class StudentManage
{
public:
    enum SortType{BY_NAME,BY_ID,BY_SPECIALTY,BY_CRDITPOINT};
    StudentManage()=default;
    void addStudent();
    void removeStudent();
    void setSortType(SortType st);
    void findStudent();
    int size()const{ return students.size();}
    friend std::ostream& operator<<(std::ostream& out,
    const StudentManage& sm);
private:
    vector<Student> students;
    SortType sortType=BY_ID;
};
void StudentManage::setSortType (SortType st)
{
    function<bool(const Student&,const Student&)> f;
    switch(st)
    {
        case BY_ID: f=[](const Student& s1,const Student& s2)
    {return s1.getName()<s2.getName();};break;
    case BY_NAME:f=[](const Student& s1,const Student& s2)
    {return s1.getId()<s2.getId();};break;
    case BY_SPECIALTY:f=[](const Student& s1,const Student& s2)
    {return s1.getSpecialty()<s2.getSpecialty();};break;
    case BY_CRDITPOINT:f=[](const Student& s1,const Student& s2)
    {return s1.getCreditPoint()<s2.getCreditPoint();};break;
    }
    sort(students.begin(),students.end(),f);
}

void StudentManage::addStudent()
{
    string newname;
    string newspecialty;
    long newid;
    double newcreditPoint;
    cout<<"请输入学生姓名:"<<endl;
    cin>>newname;
    cout<<"请输入学生专业:"<<endl;
    cin>>newspecialty;
    cout<<"请输入学生学号:"<<endl;
    cin>>newid;
    cout<<"请输入学生绩点:"<<endl;
    cin>>newcreditPoint;
    Student temp(newname,newspecialty,newid,newcreditPoint);
    this->students.push_back(temp);
    setSortType(sortType);
}

void StudentManage::removeStudent()
{
    string newname;
    string newspecialty;
    long newid;
    double newcreditPoint;
    cout<<"请输入学生姓名:"<<endl;
    cin>>newname;
    cout<<"请输入学生专业:"<<endl;
    cin>>newspecialty;
    cout<<"请输入学生学号:"<<endl;
    cin>>newid;
    cout<<"请输入学生绩点:"<<endl;
    cin>>newcreditPoint;
    Student temp(newname,newspecialty,newid,newcreditPoint);
    auto iter=find_if(students.begin(),students.end(),temp);
    if(iter==students.end())
        cout<<"404 Not Found"<<endl;
    else
        students.erase(iter);
}


void StudentManage::findStudent()
{
    int type;
    long Id;
    string Name;
    int num=0;
    cout<<"通过姓名查询请输入1，通过学号查询请输入2"<<endl;
    cout<<"请选择查询方式：";
    cin>>type;
    if(type==1)
    {
        cout<<endl<<"请输入姓名：";
        cin>>Name;
        for(vector<Student>::iterator it=students.begin();it!=students.end();++it)
        {
            if((*it).getName()==Name)
            {
                cout<<(*it)<<endl;
                num++;
            }
            if(num>1)
            {
                cout<<"有重名者，请输入学号"<<endl;
                cin>>Id;
                type=2;
            }
        }
    }
    if(type==2)
    {
        cout<<endl<<"请输入学号：";
        cin>>Id;
        for(vector<Student>::iterator it=students.begin();it!=students.end();++it)
        {
            if((*it).getId()==Id)
            {
                cout<<(*it)<<endl;
                exit(0);
            }
        }
    }
}

std::ostream& operator<<(std::ostream& out,const StudentManage& sm)
{
    for(auto it=sm.students.begin();it!=sm.students.end();++it)
    {
        out<<(*it);
        return out;
    }
}
int main(){
 StudentManage sm;
 sm.addStudent();
 sm.addStudent();
 sm.addStudent();
 sm.addStudent();

 cout<<"sort type(0-name,1-id,2-specialty,3-creditpoint):";
 int choice;
 cin>>choice;
 sm.setSortType (static_cast<StudentManage::SortType>(choice));
 cout<<sm;
 sm.findStudent ();
 sm.removeStudent ();
 cout<<sm;
 return 0;
}

