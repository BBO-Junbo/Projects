#include <iostream>
#include<iomanip>
using namespace std;

class Time
{
public:
    Time()
    {
        this->hour=0;
        this->minute=0;
        normalizeTime();
    }
    Time(int h,int m)
    {
        this->hour=h;
        this->minute=m;
        normalizeTime();
    }
    Time(int minutes) //功能增加
    {
        if(minutes>=60)
        {
            hour=minutes/60;
            minute=minutes%60;
        }
        else
        {
            hour=0;
            minute=minutes;
        }
    }
    void setTime(int h,int m)
    {
        this->hour=h;
        this->minute=m;
        normalizeTime();
    }


    friend std::ostream& operator<<( std::ostream& out, const Time& t);

    int getHour()const
    {
        return hour;
    }

    int getMinute()const
    {
        return minute;
    }

    int getTotalMinutes()const
    {
        return hour*60+minute;
    }

    Time operator-(const Time& newTime)const
    {
        int t1=this->getTotalMinutes();
        int t2=newTime.getTotalMinutes();
        int t3;
        if(t1>=t2)
           t3=t1-t2;
        else
           t3=t2-t1;
        return Time(t3);
    }


private:
    int hour;
    int minute;
    void normalizeTime()
    {

        if(minute>=60)
        {
            hour+=minute/60;
            minute=minute%60;

        }
        else
            return;
    }
};
std::ostream& operator<<( std::ostream&out, const Time& t)
{
    out<<setfill('0')<<setw(2)<<t.hour<<":"<<setw(2)<<t.minute<<endl;
    return out;
}
class ParkingCard
{
public:
    ParkingCard(double newRate):rate(newRate){};
    void setRate(double newRate)
    {
        rate=newRate;
    }
    void setParkingTime(const Time &time)
    {
        ParkingTime=time;
    }
    void setLeavingTime(const Time &time)
    {
        leavingTime=time;
    }

    double getTotalExpenses()const
    {
        Time Span=ParkingTime-leavingTime;
        double t;
        if(Span.getMinute()>0&&Span.getMinute()<=30)
        {
            t=Span.getHour()+0.5;
        }
        else
            t=Span.getHour()+1;
        return rate*t;
    }
    friend std::ostream& operator<<( std::ostream& out, const ParkingCard& t);
private:
    double rate;
    Time ParkingTime;
    Time leavingTime;

};
std::ostream& operator<<( std::ostream& out, const ParkingCard& t)
{
    out<<"Total Expenses:"<<t.getTotalExpenses()<<endl;
    out<<"Parking Time:"<<setfill('0')<<setw(2)<<t.ParkingTime.getHour()<<":"<<setw(2)<<t.ParkingTime.getMinute()<<endl;
    out<<"Leaving Time:"<<setfill('0')<<setw(2)<<t.leavingTime.getHour()<<":"<<setw(2)<<t.leavingTime.getMinute()<<endl;
    out<<"Rate:"<<t.rate<<endl;
    return out;
}
int main()
{
    ParkingCard card(5);
    card.setParkingTime(Time(9,20));
    card.setLeavingTime(Time(11,35));
    cout<<"Expenses:"<<card.getTotalExpenses()<<endl;
    cout<<"Detail info:\n";
    cout<<card;
    return 0;
}


























