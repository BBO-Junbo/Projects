#include<iostream>
#include<iomanip>
#include"MyTime.h"
#include"ParkingCard.h"
using namespace std;

int main()
{
    ParkingCard card(5);
    card.setParkingTime(Time(9,20));
    card.setLeavingTime(Time(11,35));
    cout<<"Expenses:"<<card.getTotalExpenses()<<endl;
    cout<<"Detail info:\n";
    card.output();
    return 0;
}
