#include<iostream>
#include<iomanip>
#include"MyTime.h"
using namespace std;


Time::Time()
{
    this->hour=0;
    this->minute=0;
    normalizeTime();
}
Time::Time(int h,int m)
{
    this->hour=h;
    this->minute=m;
    normalizeTime();
}
Time::Time(int minutes) //功能增加
{
    if(minutes>=10)
    {
        hour=minutes/60;
        minute=minutes%60;
    }
    else
    {
        hour=0;
        minute=minutes;
    }
}
void Time::setTime(int h,int m)
{
    this->hour=h;
    this->minute=m;
    normalizeTime();
}

void Time::output()const
{
    cout<<setfill('0')<<setw(2)<<hour<<":"<<setw(2)<<minute<<endl;
}


int Time::getHour()const
{
    return hour;
}

int Time::getMinute()const
{
    return minute;
}

int Time::getTotalMinutes()const
{
    return hour*60+minute;
}

Time Time::getTimeSpan(const Time &t)const //功能增加
{
    int t1=this->Time::getTotalMinutes();
    int t2=t.getTotalMinutes();
    int t3;
    if(t1>=t2)
        t3=t1-t2;
    else
        t3=t2-t1;
    return Time(t3);
}

void Time::normalizeTime()
{
    if(minute>=60)
    {
        hour+=minute/60;
        minute=minute%60;

    }
    else
        return;
}

