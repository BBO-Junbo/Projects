#ifndef PARKINGCARD_H
#define PARKINGCARD_H
#include"MyTime.h"
class ParkingCard
{
public:
    ParkingCard(double newRate);
    void setRate(double nweRate);
    void setParkingTime(const Time &time);
    void setLeavingTime(const Time &time);
    double getTotalExpenses()const;
    void output()const;
private:
    double rate;
    Time ParkingTime;
    Time leavingTime;

};

#endif // PARKINGCARD_H
