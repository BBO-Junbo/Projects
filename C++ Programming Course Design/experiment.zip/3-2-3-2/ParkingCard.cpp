#include<iostream>
#include<iomanip>
#include"MyTime.h"
#include"ParkingCard.h"
using namespace std;
ParkingCard::ParkingCard(double newRate):rate(newRate){};
void ParkingCard::setRate(double newRate)
{
    rate=newRate;
}
void ParkingCard::setParkingTime(const Time &time)
{
    ParkingTime=time;
}
void ParkingCard::setLeavingTime(const Time &time)
{
    leavingTime=time;
}

double ParkingCard::getTotalExpenses()const
{
    Time Span=ParkingTime.getTimeSpan(leavingTime);
    double t;
    if(Span.getMinute()>0&&Span.getMinute()<=30)
    {
        t=Span.getHour()+0.5;
    }
    else
        t=Span.getHour()+1;
    return rate*t;
}
void ParkingCard::output()const
{
    cout<<"Total Expenses:"<<getTotalExpenses()<<endl;
    cout<<"Parking Time:"<<setfill('0')<<setw(2)<<ParkingTime.getHour()<<":"<<setw(2)<<ParkingTime.getMinute()<<endl;
    cout<<"Leaving Time:"<<setfill('0')<<setw(2)<<leavingTime.getHour()<<":"<<setw(2)<<leavingTime.getMinute()<<endl;
    cout<<"Rate:"<<rate<<endl;
}

