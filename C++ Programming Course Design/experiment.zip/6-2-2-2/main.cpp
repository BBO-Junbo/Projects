#include <iostream>
using namespace std;

#include"Stack.h"
int main()
{
 int array[10]={1, 3, 2, 4};
 Stack<int> s(4); //创建堆栈 s，设置初始大小为 4
 int i;
 for( i=0;i<3; ++i)
 s.push(array[i]);
 while(!s.isEmpty())
 cout<<s.pop()<<' ';
 for( i=0;i<10; ++i)
 s.push(array[i]);
cout<<endl;
 return 0;
}
