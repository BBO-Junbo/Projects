#include<iostream>
#include<iomanip>
#include"MyTime.h"
using namespace std;

int main()
{
    Time t1(12,75);
    t1.output();
    t1.setTime(8,65);
    t1.output();
    cout<<"t1 Hour:"<<t1.getHour()<<endl;
    cout<<"t1 Minute:"<<t1.getMinute()<<endl;
    cout<<"t1 TotalMinutes:"<<t1.getTotalMinutes()<<endl;
    return 0;
}
