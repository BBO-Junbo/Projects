#ifndef MyTime_H
#define MyTime_H
class Time
{
public:
    Time();
    Time(int h,int m);
    void setTime(int h,int m);
    void output();
    int getHour();
    int getMinute();
    int getTotalMinutes();
private:
    int hour;
    int minute;
    void normalizeTime();

};
#endif
