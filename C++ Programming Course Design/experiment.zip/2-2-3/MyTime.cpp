#include<iostream>
#include<iomanip>
#include"MyTime.h"
using namespace std;


Time::Time()
{
    this->hour=0;
    this->minute=0;
    normalizeTime();
}
Time::Time(int h,int m)
{
    this->hour=h;
    this->minute=m;
    normalizeTime();
}

void Time::setTime(int h,int m)
{
    this->hour=h;
    this->minute=m;
    normalizeTime();
}

void Time::output()
{
    cout<<setfill('0')<<setw(2)<<hour<<":"<<setw(2)<<minute<<endl;
}


int Time::getHour()
{
    return hour;
}

int Time::getMinute()
{
    return minute;
}

int Time::getTotalMinutes()
{
    return hour*60+minute;
}


void Time::normalizeTime()
{
    if(minute>=60)
    {
        hour+=minute/60;
        minute=minute%60;

    }
    else
        return;
}

