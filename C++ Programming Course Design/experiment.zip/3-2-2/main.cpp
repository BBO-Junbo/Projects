#include <iostream>
#include <math.h>
using namespace std;

class Complex
{
public:
    Complex():real(0),image(0){}
    Complex(double r):real(r),image(0){};
    Complex(double r,double i):real(r),image(i){};
    void setValue(double r,double i)
        {
            this->real=r;
            this->image=i;
        }
    double getReal()const
    {
        return real;
    }
    double getImage()const
    {
        return image;
    }
    double getDistance()const
    {
        return sqrt(abs(real*real)+abs(image*image));
    }
    void output()const
    {
        if(real!=0)
        {
            if(image==0)
                cout<<real<<endl;
            else if(image>0)
                cout<<real<<"+"<<image<<"i"<<endl;
            else if(image<0)
                cout<<real<<image<<"i"<<endl;
        }
        else
        {
            if(image==0)
                cout<<"0"<<endl;
            else
                cout<<image<<"i"<<endl;
        }

    }
    Complex add(const Complex& c)const
    {
        return Complex(this->real + c.real, this->image + c.image);
    }
    Complex multiply(const Complex& c)const
    {
        return Complex(this->real * c.real - this->image * c.image, this->real * c.image + this->image * c.real);
    }

private:
    double real;
    double image;
};

int main()
{
    Complex c1,c2(2),c3(3,4),c4;
    c1.output();
    c2.output();
    c3.output();
    c1.setValue(6,4);
    c1.output();
    cout<<c1.getDistance()<<endl;
    c4=c2.add(c3);
    cout<<c4.getReal()<<endl;
    return 0;
}

