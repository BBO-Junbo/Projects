#include<iostream>
#include<iomanip>
#include"MyTime.h"
using namespace std;

int main()
{
    Time t1(9,20),t2(11,35),t3;
    t3=t1.getTimeSpan(t2);
    t3.output();
    return 0;
}
