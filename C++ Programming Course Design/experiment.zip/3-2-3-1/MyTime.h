#ifndef MyTime_H
#define MyTime_H
class Time
{
public:
    Time();
    Time(int h,int m);
    Time(int minutes);//功能增加
    void setTime(int h,int m);
    void output()const;
    int getHour()const;
    int getMinute()const;
    int getTotalMinutes()const;
    Time getTimeSpan(const Time &t)const;//功能增加
private:
    int hour;
    int minute;
    void normalizeTime();

};
#endif
