#include <iostream>
#include"PointandTriangle.h"
#include<math.h>
using namespace std;

double getDistance3(const Point&p1,const Point&p2)//3）中的内容
{
    return sqrt(pow(p1.getX()-p2.getX(),2)+pow(p1.getY()-p2.getY(),2));
}
double getDistance4(const Point&p1,const Point&p2)//4）中的内容
{
    return sqrt(pow(p1.x-p2.x,2)+pow(p1.y-p2.y,2));
}
int main()
{
    //cout<<"2):test"<<endl;
    Point p1(3,4);
    Point p2(5,2);
    double distance=p1.getDistance2(p2);
    cout<<"Distance:"<<distance<<endl<<endl;
    cout<<"3):test"<<endl;
    double distance2=getDistance3(p1,p2);
    cout<<"Distance:"<<distance2<<endl<<endl;
    cout<<"4):test"<<endl;
    double distance3=getDistance4(p1,p2);
    cout<<"Distance:"<<distance3<<endl<<endl;
    cout<<"5):test"<<endl;
    Point p4(0,0),p5(0,3),p6(4,0);
    Triangle t(p4,p5,p6);
    cout<<"Area:"<<t.getArea()<<endl;
    cout<<"Perimeter:"<<t.getPerimeter()<<endl;
    return 0;
}
