#ifndef POINT_H
#define POINT_H
#include <iostream>
#include<math.h>
using namespace std;

class Point
{
public:
    Point(double newX=0,double newY=0);
    Point(const Point&p);
    void setValue(double newX,double nweY);
    double getX()const;
    double getY()const;//以上为1）的内容
    double getDistance2(const Point&p2)const;//2）中的内容
friend double getDistance4(const Point&p1,const Point&p2);//4）中的内容
private:
    double x,y;
};

class Triangle     //5）的内容
{
public:
    Triangle(const Point&p1,const Point&p2,const Point&p3);
    double getArea()const;
    double getPerimeter()const;
private:
    Point p1,p2,p3;
};

#endif // POINT_H
