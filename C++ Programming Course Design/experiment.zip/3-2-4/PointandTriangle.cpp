#include <iostream>
#include"PointandTriangle.h"
#include<math.h>
using namespace std;

Point::Point(double newX,double newY):x(newX),y(newY){}

void Point::setValue(double newX,double newY)
{
    x=newX;
    y=newY;
}

double Point::getX()const
{
    return x;
}
double Point::getY()const
{
    return y;
}
double Point::getDistance2(const Point&p2)const//2）中的内容
{
    return sqrt(pow(this->x-p2.x,2)+pow(this->y-p2.y,2));
}
Triangle::Triangle(const Point&p1,const Point&p2,const Point&p3)
{
    this->p1=p1;
    this->p2=p2;
    this->p3=p3;
}

double Triangle::getArea()const//S=(1/2)*(x1y2+x2y3+x3y1-x1y3-x2y1-x3y2)
{
    return abs(0.5*(p1.getX()*p2.getY()+p2.getX()*p3.getY()+p3.getX()*p1.getY()-p1.getX()*p3.getY()-p2.getX()*p1.getY()-p3.getX()*p2.getY()));
}
double Triangle::getPerimeter()const
{
    return p1.getDistance2(p2)+p1.getDistance2(p3)+p2.getDistance2(p3);
}
