#include <iostream>
#include<iomanip>
using namespace std;

class Time
{
public:
    Time()
    {
        this->hour=0;
        this->minute=0;
        normalizeTime();
    }
    Time(int h,int m)
    {
        this->hour=h;
        this->minute=m;
        normalizeTime();
    }
    Time(int minutes) //功能增加
    {
        if(minutes>=60)
        {
            hour=minutes/60;
            minute=minutes%60;
        }
        else
        {
            hour=0;
            minute=minutes;
        }
    }
    void setTime(int h,int m)
    {
        this->hour=h;
        this->minute=m;
        normalizeTime();
    }


    friend std::ostream& operator<<( std::ostream& out, const Time& t);

    int getHour()const
    {
        return hour;
    }

    int getMinute()const
    {
        return minute;
    }

    int getTotalMinutes()const
    {
        return hour*60+minute;
    }

    Time operator-(const Time& newTime)const
    {
        int t1=this->getTotalMinutes();
        int t2=newTime.getTotalMinutes();
        int t3;
        if(t1>=t2)
           t3=t1-t2;
        else
           t3=t2-t1;
        return Time(t3);
    }


private:
    int hour;
    int minute;
    void normalizeTime()
    {

        if(minute>=60)
        {
            hour+=minute/60;
            minute=minute%60;

        }
        else
            return;
    }
};
std::ostream& operator<<( std::ostream&out, const Time& t)
{
    out<<setfill('0')<<setw(2)<<t.hour<<":"<<setw(2)<<t.minute<<endl;
    return out;
}
int main()
{
    Time t1(9,20),t2(11,35),t3;
    cout<<t1;
    t3=t2-t1;
    cout<<t3;
    return 0;
}

