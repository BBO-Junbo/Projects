#include <iostream>
#include <cstring>
using namespace std;
class MyString{
public:
    MyString(char *s)
    {
        str=new char[strlen(s)+1];
        strcpy(str,s);
    }
    MyString()
    {
        str=nullptr;
    }
    MyString(const MyString& s)
    {
        str=new char[strlen(s.str)];
        strcpy(str,s.str);
    }

    MyString(MyString&& s)
    {
        str=new char[strlen(s.str)];
        strcpy(str,s.str);
    }

    ~MyString()
    {
        if(str!=NULL)
            delete str;
    }

    MyString& operator=(const MyString& s)
    {
        strcpy(str,s.str);
        return *this;
    }

    MyString& operator=(MyString&& s)
    {
        strcpy(str,s.str);
        return *this;
    }

    int size()const;
    MyString operator+(const MyString& s)const
    {
        return strcat(this->str,s.str);
    }
    char& operator[](int index)
    {
        return str[index];
    }

    const char& operator[](int index) const
    {
        return str[index];
    }
    friend std::ostream& operator<<( std::ostream& out,const MyString& s);
private:
    char *str;
};
std::ostream& operator<<( std::ostream& out,const MyString& s)
{
    out<<s.str<<endl;
    return out;
}

int main(){
    MyString s("Hello");
    cout<<s<<endl;
    MyString s2=s+"World";
    cout<<s2<<endl;
    cout<<"Index 5:"<<s2[5]<<endl;
    MyString s3(move(s2));
    cout<<s3<<endl;
    return 0;
}
