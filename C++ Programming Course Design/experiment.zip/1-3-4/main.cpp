#include <iostream>
#include <ctime>

using namespace std;
int add(int a,int b);
int sub(int a,int b);
int multiply(int a,int b);
int chu(int a,int b);
char menu();
bool answerQuestion(int num1,int num2,int(*f)(int,int),int answer);
int main()
{
    int correct=0,wrong=0,i,numq=0;

    srand((unsigned)time(NULL));
    while(true)
    {
        char choice=menu();
        if(choice=='0')
            break;
        int num1,num2;
        num1=rand()%90+10;
        num2=rand()%90+10;
        if(choice=='4')
        {
            while(num1%num2!=0)
            {
                num1=rand()%90+10;
                num2=rand()%90+10;
            }
        }
        decltype (add)*pf;
        char op;
        switch(choice)
        {
            case '1':pf=add;op='+';break;
            case '2':pf=sub;op='-';break;
            case '3':pf=multiply;op='*';break;
            case '4':pf=chu;op='/';break;
            default:continue;
        }
        int answer;
        cout<<num1<<op<<num2<<"=?";


        for(i=0;i<3;i++)
        {   cin>>answer;
            if(answerQuestion(num1,num2,pf,answer)==true)
            {
                cout<<"Correct!"<<endl;
                correct++;
                i=4;
            }
            else
            {
                cout<<"Wrong!"<<endl<<num1<<op<<num2<<"=?";
            }
        }
        if(i==3)
            wrong++;

        numq++;
    }
    cout<<"you complete"<<numq<<"question"<<endl;
    cout<<"the rate of correct is";
    printf("%f%%",correct*100.0/numq);
    cout<<endl;




    return 0;
}

