#include <iostream>
using namespace std;
int add(int a,int b)
{
    return a+b;
}
int sub(int a,int b)
{
    return a-b;
}
int multiply(int a,int b)
{
    return a*b;
}
int chu(int a,int b)
{
    return a/b;
}

char menu()
{
    char choice;
    cout<<"0)quit";
    cout<<"1)add two number\n";
    cout<<"2)sub two number\n";
    cout<<"3)multiply two number\n";
    cout<<"4)chu two number\n";
    cout<<"Enter your choice:\n";
    cin>>choice;
    return choice;
}
bool answerQuestion(int num1,int num2,int(*f)(int,int),int answer)
{
    return f(num1,num2)==answer;
}
