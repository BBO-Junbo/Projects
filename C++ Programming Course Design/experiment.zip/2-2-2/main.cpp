#include <iostream>
#include <math.h>
using namespace std;

class Complex
{
public:
    Complex()
    {
        this->real=0;
        this->image=0;
    }
    Complex(double r)
    {
        this->real=r;
        this->image=0;
    }
    Complex(double r,double i)
    {
        this->real=r;
        this->image=i;
    }
    void setValue(double r,double i)
    {
        this->real=r;
        this->image=i;
    }
    double getReal()
    {
        return real;
    }
    double getImage()
    {
        return image;
    }
    double getDistance()
    {
        return sqrt(abs(real*real)+abs(image*image));
    }
    void output()
    {
        if(real!=0)
        {
            if(image==0)
                cout<<real<<endl;
            else if(image>0)
                cout<<real<<"+"<<image<<"i"<<endl;
            else if(image<0)
                cout<<real<<image<<"i"<<endl;
        }
        else
        {
            if(image==0)
                cout<<"0"<<endl;
            else
                cout<<image<<"i"<<endl;
        }

    }

private:
    double real;
    double image;
};

int main()
{
    Complex c1,c2(2),c3(3,4);
    c1.output();
    c2.output();
    c3.output();
    c1.setValue(6,4);
    c1.output();
    cout<<c1.getDistance()<<endl;
    return 0;
}

